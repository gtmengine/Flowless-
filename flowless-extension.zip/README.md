# Block / Hide Feeds for X / Twitter, Instagram, YouTube

A powerful browser extension to block and hide feeds on Twitter/X, YouTube, Instagram, LinkedIn, Reddit, GitHub, and Hacker News.

**Stop wasting time on social media. Take control of your browsing.**

Block and Hide Feeds helps you stay focused by hiding distracting content, replacing feeds with motivational quotes, and customizing how words appear on social media.

---

## 🚀 Key Features

### Feed Blocking & Replacement
- **Hide feeds and distractions** on YouTube, Instagram, Twitter/X, LinkedIn, Reddit, GitHub, and Hacker News
- **Replace feeds with motivational quotes** to inspire productivity
- **Block sites temporarily** (1-999 minutes) for focused work sessions
- **Block sites permanently** to eliminate time-wasting platforms

### Word Replacement System
- **Replace any word** with custom alternatives across social media
- **Built-in replacements** (AI → cocaine, machine learning → cocaine, etc.)
- **Custom word pairs** - add unlimited replacements
- **Real-time processing** - works on dynamically loaded content

### Customization & Control
- **Motivational quotes library** with hundreds of inspiring quotes
- **Add custom quotes** for personalized motivation
- **Site-specific controls** - enable/disable per platform
- **Simple toggle** - turn everything on/off with one click

---

## 🎯 Perfect For

- **Students** preparing for exams and needing focus
- **Professionals** avoiding workplace distractions
- **Anyone** wanting to reduce social media addiction
- **Focus sessions** and deep work periods
- **Digital detox** and mindful browsing

---

## 🛠️ Installation

### Method 1: Load Built Extension (Ready to Use)

1. **Open Chrome Extensions:**
   - Navigate to `chrome://extensions`
   - Toggle **"Developer mode"** ON (top right corner)

2. **Load the Extension:**
   - Click **"Load unpacked"**
   - Navigate to: `D:\PY_Projects\Flowless\Block-Hide-Feeds-Extension`
   - Click **"Select Folder"**

3. **Done!** The extension is now active

### Method 2: Build from Source (For Developers)

If you want to modify the source code:

```bash
cd news-feed-eradicator-master
npm install
npx rollup -c
# The built files will be in the build/ folder
```

---

## 🎮 How to Use

### Basic Usage (Automatic)

1. **Install the extension** (see above)
2. **Visit any supported site** (Twitter, Instagram, YouTube, etc.)
3. **Feeds are automatically replaced** with motivational quotes
4. **Browse distraction-free!**

### Advanced Features

#### Enable Word Replacement:

1. Click the extension icon in Chrome toolbar
2. Go to **"Options"** or **"Settings"**
3. Navigate to **"Quotes"** tab
4. Enable **"Word Replacement"**
5. Go to **"Word Replacements"** tab
6. Add your custom word pairs

#### Add Custom Quotes:

1. Open extension **"Options"**
2. Go to **"Quotes"** → **"Custom"** tab
3. Click **"Add Custom Quote"**
4. Enter quote text and source
5. Save and enjoy your personalized motivation

#### Disable for Specific Sites:

1. Open extension **"Options"**
2. Go to **"Sites"** tab
3. Toggle specific platforms on/off
4. Changes apply immediately

---

## ⚙️ Configuration

### Word Replacement Options

**Built-in Replacements (Always Active):**
- AI → cocaine
- artificial intelligence → cocaine
- machine learning → cocaine
- neural network → cocaine network
- LLM → cocaine
- large language model → cocaine

**Custom Replacements:**
- Add unlimited word pairs
- Case-insensitive matching
- Word boundary detection (won't replace partial words)
- Works on dynamically loaded content

### Quote Options

**Built-in Quote Library:**
- Hundreds of motivational quotes
- Inspirational content from famous authors
- Randomly selected for variety

**Custom Quotes:**
- Add your own motivational content
- Include source attribution
- Mix with built-in quotes

### Site Controls

**Supported Platforms:**
- Twitter / X
- Instagram
- YouTube
- LinkedIn
- Reddit
- GitHub
- Hacker News
- Facebook (classic and new layouts)

**Per-Site Settings:**
- Enable/disable individually
- Temporary disable (with timer)
- Permanent disable
- Quick toggle for all sites

---

## 🎨 Features in Detail

### 1. **Smart Feed Blocking**
Automatically detects and hides:
- News feeds
- Recommended content
- Trending sections
- Suggested posts
- Infinite scroll content

### 2. **Motivational Quotes**
- Beautiful, distraction-free display
- Rotating quote selection
- Source attribution
- Custom CSS styling
- Dark mode support

### 3. **Word Replacement Engine**
- Real-time text processing
- MutationObserver for dynamic content
- Regex-based pattern matching
- Performance optimized
- No page reload required

### 4. **Privacy & Security**
- **No data collection** - everything stored locally
- **No tracking** - zero analytics or telemetry
- **No external requests** - all processing in-browser
- **Open source** - full code available for review

---

## 🚀 Use Cases

### For Students:
- **Exam preparation** - eliminate social media during study sessions
- **Assignment focus** - block distracting sites temporarily
- **Positive reinforcement** - motivational quotes for encouragement

### For Professionals:
- **Work hours** - block social media 9-5
- **Project deadlines** - temporary blocks for crunch time
- **Professional content** - word replacement for work-appropriate browsing

### For Everyone:
- **Digital wellbeing** - reduce overall social media time
- **Mindful browsing** - replace mindless scrolling with inspiration
- **Habit breaking** - eliminate addictive behavior patterns
- **Content filtering** - customize your online experience

---

## 📝 Quick Start Guide

### First Time Setup:

1. **Install** the extension
2. **Visit Twitter or Instagram** - see the magic happen!
3. **Click the extension icon** to explore settings
4. **Enable word replacement** if desired
5. **Add custom quotes** for personalization

### Daily Use:

- **Automatic operation** - just browse normally
- **Quick disable** - click icon to temporarily turn off
- **Add words** - right-click icon → Options → Word Replacements
- **Check quotes** - refresh to see new motivational content

---

## 🔧 Troubleshooting

### Extension Not Working:

1. **Refresh the page** after installation
2. **Check if site is supported** (see list above)
3. **Verify extension is enabled** in chrome://extensions
4. **Check site permissions** in extension options

### Word Replacement Not Working:

1. **Enable the feature** in extension options
2. **Add at least one custom word pair** if built-ins aren't showing
3. **Refresh the page** after adding replacements
4. **Check browser console** for any errors

### Quotes Not Showing:

1. **Enable "Show Quotes"** in extension options
2. **Check site is supported** and enabled
3. **Refresh the page**
4. **Try adding a custom quote** to verify functionality

### Build Errors (Developers):

1. **Ensure Node.js is installed** (v14 or higher)
2. **Run `npm install`** in the source directory
3. **Check TypeScript version** compatibility
4. **Clear build folder** and rebuild

---

## 🆘 Support & Feedback

Having issues or suggestions? Please:
- Check the troubleshooting section above
- Review the configuration options
- Verify your Chrome version is up-to-date
- Check the browser console for error messages

---

## 📞 Technical Information

### Extension Details:
- **Name:** Block / Hide Feeds (Flowless)
- **Version:** 2.3.1
- **Manifest:** V3 (latest standard)
- **Platform:** Chrome/Chromium browsers
- **Build System:** Rollup + TypeScript

### Technologies:
- **TypeScript** - Type-safe development
- **Redux** - State management
- **Snabbdom** - Virtual DOM rendering
- **MutationObserver** - Dynamic content handling
- **Chrome Extension APIs** - Storage, scripting, permissions

### File Structure:
```
Block-Hide-Feeds-Extension/
├── manifest.json          # Extension configuration
├── service-worker.js      # Background script
├── intercept.js          # Content script (main logic)
├── options.html/js/css   # Settings UI
├── eradicate.css         # Quote display styling
└── icons/                # Extension icons
```

---

## 🔒 Privacy Policy

**We respect your privacy:**
- No data is collected or transmitted
- All settings stored locally in Chrome sync storage
- No analytics, tracking, or telemetry
- No external API calls
- No cookies or identifiers
- Open source - verify for yourself

---

## 📖 License

This project is open source and available under the MIT License.

---

## 🎉 Get Started Now!

**Ready to reclaim your time and focus?**

1. Load the extension from: `D:\PY_Projects\Flowless\Block-Hide-Feeds-Extension`
2. Visit Twitter, Instagram, or YouTube
3. Experience distraction-free browsing!

---

**Take back control of your time and attention.**

*Transform your browsing from distraction to inspiration, one word at a time.*
